import pandas as pd

new_column_order = ['날짜', '타입', '식사시간', '메뉴', '식당']

def csv_to_txt(menu_csv_filename, notice_csv_filename, scehdule_csv_filename, txt_filename, new_column_order):
    try:
        # CSV 파일을 읽어옴
        menu_df = pd.read_csv(menu_csv_filename)
        notice_df = pd.read_csv(notice_csv_filename)
        schedule_df = pd.read_csv(schedule_csv_filename)

         # 열 순서 변경
        menu_df = menu_df[new_column_order]

        # 데이터프레임을 텍스트 파일로 저장
        with open(txt_filename, 'a', encoding='cp949') as t:
            t.write('\n\n')
            t.write('#금정회관 학식 메뉴# (질문 예시 : 금정회관 학식 메뉴 알려줘, 학식 메뉴 알려줘, 오늘 학식 아침 메뉴 뭐야?)\n')
            t.write('반드시 학식이나 금정회관에 관한 정보가 포함되어야함.\n')
            t.write('타입은 "1000원의 아침", "일반", "일품"이 있음, 식사시간은 breakfast는 아침, lunch는 점심, dinner은 저녁임.\n')
            t.write('날짜와 타입을 둘 다 받아야함. (하나라도 빠질 시 반드시 다시 물어볼 것)\n')
            t.write('1000원의 아침은 아침만 제공됨.\n')
            t.write('일품은 점심, 저녁만 제공됨.\n')
            t.write('일반은 아침, 점심, 저녁 셋다 제공됨.\n')
            t.write('대답은 {날짜}의 금정회관 {타입} 메뉴는 아래와 같습니다.\n')
            t.write('-아침 :\n')
            t.write('-점심 :\n')
            t.write('-저녁 :\n')
            t.write(f'날짜의 범위는 {min(menu_df["날짜"])}에서 {max(menu_df["날짜"])}까지이며 날짜가 범위 내에 있는 경우에만 해당하는 메뉴 출력.\n')
            t.write(f'만일 물어본 날짜가 날짜의 범위 내에 없으면 정보가 없다고 출력.\n')
            t.write('표는 총 5개의 열이 있으며 열 구분은 |단위로 구분함 (날짜|타입|식사시간|메뉴|식당)로 표기.\n')
            t.write('\n')
        menu_df.to_csv(txt_filename, index=False, sep='|', mode='a', encoding='cp949')
           
        with open(txt_filename, 'a', encoding='cp949') as t:   
            t.write('\n\n')
            t.write('#전기공학과 공지# (질문 예시 : 전기공 공지 알려줘, 전기과 공지 알려줘, 공지 알려줘)\n')
            t.write('#전기공학과 공지#')
            t.write('\n') 
        notice_df.to_csv(txt_filename, index=False, mode='a', encoding='cp949')
        
        with open(txt_filename, 'a', encoding='cp949') as t:          
            t.write('\n\n')
            t.write('#학사일정# (질문 예시 : 학사일정 알려줘, 부산대 학사일정 알려줘)\n')
            t.write('#학사일정#')
            t.write('\n')       
        schedule_df.to_csv(txt_filename, index=False, sep='|', mode='a', encoding='cp949')

        print(f"텍스트 파일 {txt_filename}이 생성되었습니다.")

    except Exception as e:
        print(f"오류: {e}")


# 크롤링한 CSV 파일명과 저장할 텍스트 파일명을 지정
menu_csv_filename = 'menu_student.csv'
notice_csv_filename = 'notice_data.csv'
schedule_csv_filename = 'schedule_data.csv'

txt_filename = 'PDSPrompt.txt'

# 함수 호출
csv_to_txt(menu_csv_filename, notice_csv_filename, schedule_csv_filename, txt_filename, new_column_order)
